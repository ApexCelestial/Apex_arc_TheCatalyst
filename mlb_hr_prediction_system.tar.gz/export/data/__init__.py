# data/__init__.py
# Package initialization for data
