# trackers/__init__.py
# Package initialization for trackers
