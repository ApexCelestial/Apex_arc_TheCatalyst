# overlays/weather_overlay.py
# Weather Impact Overlay for HR Prediction

import pandas as pd

def apply_weather_overlay(player_df):
    """
    Modifies player dataframe by applying weather-based HR probability boosts or downgrades.
    Uses temperature, wind speed/direction, and humidity to adjust HR probabilities.
    
    Parameters:
    -----------
    player_df : pandas.DataFrame
        DataFrame containing player data with weather conditions
        
    Returns:
    --------
    pandas.DataFrame
        DataFrame with added 'WeatherBoost' column
    """

    print(">> Applying Weather Overlay...")

    # Ensure necessary columns exist
    required_cols = ['Temperature', 'WindSpeed', 'WindDirection', 'Humidity']
    for col in required_cols:
        if col not in player_df.columns:
            print(f"WARNING: Missing column {col} for weather overlay, adding default values")
            player_df[col] = 0 if col != 'WindDirection' else 'Neutral'

    # Initialize weather boost
    player_df['WeatherBoost'] = 0.0

    # Temperature Effect
    player_df.loc[player_df['Temperature'] >= 80, 'WeatherBoost'] += 0.05  # Hot = HRs travel farther
    player_df.loc[player_df['Temperature'] <= 60, 'WeatherBoost'] -= 0.05  # Cold = HRs suppressed
    
    # Wind Effect (Assume WindDirection == "Out" or "In" relative to batter)
    player_df.loc[(player_df['WindDirection'] == 'Out') & (player_df['WindSpeed'] >= 10), 'WeatherBoost'] += 0.07
    player_df.loc[(player_df['WindDirection'] == 'In') & (player_df['WindSpeed'] >= 10), 'WeatherBoost'] -= 0.07
    
    # Humidity Effect
    player_df.loc[player_df['Humidity'] >= 70, 'WeatherBoost'] += 0.02  # Humid air = ball flies better
    player_df.loc[player_df['Humidity'] <= 30, 'WeatherBoost'] -= 0.02  # Dry air = slight downgrade

    # Additional wind impact based on speed tiers
    player_df.loc[(player_df['WindDirection'] == 'Out') & (player_df['WindSpeed'] >= 15), 'WeatherBoost'] += 0.03  # Strong outward wind
    player_df.loc[(player_df['WindDirection'] == 'In') & (player_df['WindSpeed'] >= 15), 'WeatherBoost'] -= 0.03  # Strong inward wind
    
    # Weather combination effects (hot + outward wind = extra boost)
    player_df.loc[(player_df['Temperature'] >= 80) & 
                  (player_df['WindDirection'] == 'Out') & 
                  (player_df['WindSpeed'] >= 8), 'WeatherBoost'] += 0.03  # Hot day with outward wind
    
    # Cap the boost/penalty to reasonable limits
    player_df['WeatherBoost'] = player_df['WeatherBoost'].clip(-0.15, 0.15)
    
    return player_df
