# overlays/batter_overlay.py
# Batter Performance Overlay for HR Prediction

import pandas as pd
import numpy as np
import os
from datetime import datetime, timedelta

def apply_batter_overlay(player_df):
    """
    Applies batter performance analysis to adjust HR probabilities.
    Factors in recent form (7-day trends), hot streaks, and batter vs. pitcher history.
    
    Parameters:
    -----------
    player_df : pandas.DataFrame
        DataFrame containing player performance data
        
    Returns:
    --------
    pandas.DataFrame
        DataFrame with added 'HotStreakBoost' column
    """
    
    print(">> Applying Batter Overlay...")
    
    # Load recent performance data if available
    recent_stats_file = 'data/recent_player_stats.csv'
    bvp_file = 'data/batter_vs_pitcher.csv'  # Batter vs Pitcher history
    
    # Initialize hot streak boost
    player_df['HotStreakBoost'] = 0.0
    
    # Process recent performance data if available
    if os.path.exists(recent_stats_file):
        recent_stats = pd.read_csv(recent_stats_file)
        
        # Merge recent stats into player data
        player_df = player_df.merge(
            recent_stats[['PlayerID', 'Last7HR', 'Last7BA', 'Last7SLG', 'DaysSinceLastHR']], 
            on='PlayerID', 
            how='left'
        )
    else:
        print(f"WARNING: Recent stats file {recent_stats_file} not found, using default values")
        # Add default columns
        player_df['Last7HR'] = 0
        player_df['Last7BA'] = 0.250
        player_df['Last7SLG'] = 0.400
        player_df['DaysSinceLastHR'] = 7
    
    # Fill missing values
    player_df['Last7HR'] = player_df['Last7HR'].fillna(0)
    player_df['Last7BA'] = player_df['Last7BA'].fillna(0.250)
    player_df['Last7SLG'] = player_df['Last7SLG'].fillna(0.400)
    player_df['DaysSinceLastHR'] = player_df['DaysSinceLastHR'].fillna(7)
    
    # Apply recent HR performance boost
    player_df.loc[player_df['Last7HR'] >= 3, 'HotStreakBoost'] += 0.12  # 3+ HR in last 7 days = hot
    player_df.loc[(player_df['Last7HR'] == 2), 'HotStreakBoost'] += 0.08  # 2 HR in last 7 days
    player_df.loc[(player_df['Last7HR'] == 1), 'HotStreakBoost'] += 0.04  # 1 HR in last 7 days
    
    # Apply recent batting average boost
    player_df.loc[player_df['Last7BA'] >= 0.400, 'HotStreakBoost'] += 0.07  # Very hot
    player_df.loc[(player_df['Last7BA'] >= 0.350) & (player_df['Last7BA'] < 0.400), 'HotStreakBoost'] += 0.04
    player_df.loc[player_df['Last7BA'] <= 0.150, 'HotStreakBoost'] -= 0.05  # Cold streak
    
    # Apply recent slugging percentage boost
    player_df.loc[player_df['Last7SLG'] >= 0.700, 'HotStreakBoost'] += 0.08  # Power surge
    player_df.loc[(player_df['Last7SLG'] >= 0.550) & (player_df['Last7SLG'] < 0.700), 'HotStreakBoost'] += 0.05
    player_df.loc[player_df['Last7SLG'] <= 0.300, 'HotStreakBoost'] -= 0.05  # Power outage
    
    # Apply recency bias for last HR (if it was recent, they might be due for regression)
    player_df.loc[player_df['DaysSinceLastHR'] <= 1, 'HotStreakBoost'] -= 0.02  # Just hit one, slight regression
    player_df.loc[(player_df['DaysSinceLastHR'] >= 10) & (player_df['HR_Season'] >= 15), 'HotStreakBoost'] += 0.03  # Due for HR (power hitter)
    
    # Process batter vs pitcher data if available
    if os.path.exists(bvp_file):
        bvp_stats = pd.read_csv(bvp_file)
        
        # Merge bvp stats into player data
        player_df = player_df.merge(
            bvp_stats[['PlayerID', 'PitcherID', 'AtBats', 'BVP_HR', 'BVP_AVG', 'BVP_SLG']], 
            on=['PlayerID', 'PitcherID'], 
            how='left'
        )
        
        # Apply BVP boost only if sufficient sample size (at least 10 ABs)
        player_df.loc[(player_df['AtBats'] >= 10) & (player_df['BVP_HR'] >= 2), 'HotStreakBoost'] += 0.06  # Good HR history vs pitcher
        player_df.loc[(player_df['AtBats'] >= 10) & (player_df['BVP_AVG'] >= 0.350), 'HotStreakBoost'] += 0.04  # Good average vs pitcher
        player_df.loc[(player_df['AtBats'] >= 10) & (player_df['BVP_SLG'] >= 0.600), 'HotStreakBoost'] += 0.05  # Good slugging vs pitcher
        
        # Drop BVP columns after calculation
        player_df = player_df.drop(['AtBats', 'BVP_HR', 'BVP_AVG', 'BVP_SLG'], axis=1, errors='ignore')
    
    # Check for injury flags (if available)
    if 'InjuryFlag' in player_df.columns:
        player_df.loc[player_df['InjuryFlag'] == True, 'HotStreakBoost'] -= 0.10  # Injury concern
    
    # Drop the temporary columns used for calculation
    player_df = player_df.drop(['Last7HR', 'Last7BA', 'Last7SLG', 'DaysSinceLastHR'], axis=1, errors='ignore')
    
    # Cap the boost/penalty to reasonable limits
    player_df['HotStreakBoost'] = player_df['HotStreakBoost'].clip(-0.15, 0.15)
    
    return player_df
