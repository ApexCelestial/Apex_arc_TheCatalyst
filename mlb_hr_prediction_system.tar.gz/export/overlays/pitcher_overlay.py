# overlays/pitcher_overlay.py
# Pitcher Matchup Overlay for HR Prediction

import pandas as pd
import os

def apply_pitcher_overlay(player_df):
    """
    Applies pitcher matchup analysis to adjust HR probabilities.
    Factors in HR/9, K%, hard hit rate, and other pitcher tendencies.
    
    Parameters:
    -----------
    player_df : pandas.DataFrame
        DataFrame containing player and opposing pitcher data
        
    Returns:
    --------
    pandas.DataFrame
        DataFrame with added 'PitcherHRBoost' column
    """
    
    print(">> Applying Pitcher Overlay...")
    
    # Load pitcher data or create default if not available
    pitcher_data_file = 'data/pitcher_stats.csv'
    
    if os.path.exists(pitcher_data_file):
        pitcher_df = pd.read_csv(pitcher_data_file)
    else:
        print(f"WARNING: Pitcher data file {pitcher_data_file} not found, using default factors")
        # Create minimal pitcher data with synthetic values
        pitcher_data = {
            'PitcherID': list(range(1, 11)),
            'Pitcher': [f'Pitcher{i}' for i in range(1, 11)],
            'Team': ['TEA', 'TEB', 'TEC', 'TED', 'TEE', 'TEF', 'TEG', 'TEH', 'TEI', 'TEJ'],
            'HR9': [0.8, 1.2, 1.5, 0.5, 1.1, 1.7, 0.9, 1.0, 1.3, 1.0],
            'HardHit%': [35.0, 42.0, 45.0, 31.0, 38.0, 46.0, 33.0, 37.0, 40.0, 36.0],
            'K%': [22.0, 19.0, 17.0, 25.0, 20.0, 16.0, 23.0, 21.0, 18.0, 22.0],
            'WHIP': [1.15, 1.25, 1.40, 1.05, 1.20, 1.45, 1.10, 1.18, 1.30, 1.21]
        }
        pitcher_df = pd.DataFrame(pitcher_data)
    
    # Ensure necessary columns exist in player_df
    if 'OpposingPitcher' not in player_df.columns:
        print("WARNING: Missing OpposingPitcher column, adding default values")
        player_df['OpposingPitcher'] = 'DefaultPitcher'
    
    # Initialize pitcher HR boost
    player_df['PitcherHRBoost'] = 0.0
    
    # Merge pitcher stats into player data
    player_df = player_df.merge(
        pitcher_df[['Pitcher', 'HR9', 'HardHit%', 'K%', 'WHIP']], 
        left_on='OpposingPitcher', 
        right_on='Pitcher', 
        how='left'
    )
    
    # Fill missing values with league average
    league_avg = {
        'HR9': 1.2,
        'HardHit%': 38.0,
        'K%': 22.0,
        'WHIP': 1.25
    }
    
    for stat, avg in league_avg.items():
        player_df[stat] = player_df[stat].fillna(avg)
    
    # Calculate pitcher-specific HR boost
    # HR9 impact (higher HR9 = higher HR probability)
    player_df.loc[player_df['HR9'] >= 1.5, 'PitcherHRBoost'] += 0.10
    player_df.loc[(player_df['HR9'] >= 1.2) & (player_df['HR9'] < 1.5), 'PitcherHRBoost'] += 0.05
    player_df.loc[(player_df['HR9'] <= 0.8), 'PitcherHRBoost'] -= 0.05
    player_df.loc[(player_df['HR9'] <= 0.5), 'PitcherHRBoost'] -= 0.10
    
    # Hard Hit% impact (higher hard hit allowed = higher HR probability)
    player_df.loc[player_df['HardHit%'] >= 45, 'PitcherHRBoost'] += 0.07
    player_df.loc[(player_df['HardHit%'] >= 40) & (player_df['HardHit%'] < 45), 'PitcherHRBoost'] += 0.04
    player_df.loc[(player_df['HardHit%'] <= 33), 'PitcherHRBoost'] -= 0.04
    player_df.loc[(player_df['HardHit%'] <= 30), 'PitcherHRBoost'] -= 0.07
    
    # K% impact (higher K% = lower HR probability)
    player_df.loc[player_df['K%'] >= 28, 'PitcherHRBoost'] -= 0.06
    player_df.loc[(player_df['K%'] >= 24) & (player_df['K%'] < 28), 'PitcherHRBoost'] -= 0.03
    player_df.loc[(player_df['K%'] <= 18), 'PitcherHRBoost'] += 0.03
    player_df.loc[(player_df['K%'] <= 16), 'PitcherHRBoost'] += 0.06
    
    # WHIP impact (higher WHIP = higher HR probability)
    player_df.loc[player_df['WHIP'] >= 1.40, 'PitcherHRBoost'] += 0.05
    player_df.loc[(player_df['WHIP'] >= 1.30) & (player_df['WHIP'] < 1.40), 'PitcherHRBoost'] += 0.03
    player_df.loc[(player_df['WHIP'] <= 1.10), 'PitcherHRBoost'] -= 0.03
    player_df.loc[(player_df['WHIP'] <= 1.00), 'PitcherHRBoost'] -= 0.05
    
    # Remove the pitcher stats columns as they were just for calculation
    player_df = player_df.drop(['Pitcher', 'HR9', 'HardHit%', 'K%', 'WHIP'], axis=1)
    
    return player_df
