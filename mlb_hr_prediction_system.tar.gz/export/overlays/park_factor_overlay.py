# overlays/park_factor_overlay.py
# Park Factor Overlay for HR Prediction

import pandas as pd
import numpy as np
import os

def apply_park_factor_overlay(player_df):
    """
    Applies stadium park factors to player HR probabilities.
    Accounts for home/away games and stadium-specific HR tendencies.
    
    Parameters:
    -----------
    player_df : pandas.DataFrame
        DataFrame containing player data with stadium information
        
    Returns:
    --------
    pandas.DataFrame
        DataFrame with added 'ParkFactorBoost' column
    """
    
    print(">> Applying Park Factor Overlay...")
    
    # Load park factors data
    # If we can't find the data, create minimal version with default values
    park_factors_file = 'data/park_factors.csv'
    
    if os.path.exists(park_factors_file):
        park_factors = pd.read_csv(park_factors_file)
    else:
        print(f"WARNING: Park factors file {park_factors_file} not found, using default factors")
        # Create minimal park factors with some known extreme parks
        # Park Factor over 100 = hitter-friendly, under 100 = pitcher-friendly
        park_data = {
            'Stadium': [
                'Coors Field', 'Great American Ball Park', 'Yankee Stadium', 
                'Oracle Park', 'Dodger Stadium', 'Fenway Park',
                'T-Mobile Park', 'Petco Park', 'Tropicana Field',
                'Default Park'
            ],
            'Team': [
                'COL', 'CIN', 'NYY', 'SF', 'LAD', 'BOS', 'SEA', 'SD', 'TB', 'DEFAULT'
            ],
            'HR_Factor': [
                1.25, 1.18, 1.15, 0.82, 0.97, 1.10, 0.85, 0.88, 0.90, 1.00
            ]
        }
        park_factors = pd.DataFrame(park_data)
    
    # Ensure necessary columns exist in player_df
    required_cols = ['Stadium', 'IsHome']
    for col in required_cols:
        if col not in player_df.columns:
            print(f"WARNING: Missing column {col} for park factor overlay, adding default values")
            if col == 'Stadium':
                player_df[col] = 'Default Park'
            elif col == 'IsHome':
                player_df[col] = True
    
    # Initialize park factor boost
    player_df['ParkFactorBoost'] = 0.0
    
    # Merge park factors into player data
    player_df = player_df.merge(
        park_factors[['Stadium', 'HR_Factor']], 
        on='Stadium', 
        how='left'
    )
    
    # Fill missing values with default park factor
    player_df['HR_Factor'] = player_df['HR_Factor'].fillna(1.0)
    
    # Calculate boost based on park factor
    # Convert factor to boost centered around 0
    # E.g., factor 1.15 becomes boost of 0.15, factor 0.90 becomes -0.10
    player_df['ParkFactorBoost'] = player_df['HR_Factor'] - 1.0
    
    # Additional adjustment for home vs away (home field advantage)
    player_df.loc[player_df['IsHome'], 'ParkFactorBoost'] += 0.02
    
    # Remove the HR_Factor column as it was just for calculation
    player_df = player_df.drop('HR_Factor', axis=1)
    
    return player_df
